package com.sirisdevelopment.swiftly.data.objects

import com.google.gson.annotations.SerializedName
import com.sirisdevelopment.swiftly.models.ManagerSpecialDataModel
import com.sirisdevelopment.swiftly.models.ManagersSpecialListDataModel
import java.lang.NumberFormatException

class SwiftlyGrocerManagersSpecialDataPacket: ManagersSpecialListDataModel {
    @SerializedName("canvasUnit")
    override var canvasUnit = 0

    @SerializedName("managerSpecials")
    override var managerSpecialItemList: List<SwiftlyManagerSpecialItem> = ArrayList()
}

class SwiftlyManagerSpecialItem: ManagerSpecialDataModel {
    @SerializedName("display_name")
    override var displayName: String = ""

    @SerializedName("height")
    override var height = 0

    @SerializedName("width")
    override var width = 0

    @SerializedName("original_price")
    var originalPriceString: String = "-1"
    set(value) {
        field = value
        try {
            originalPriceInDollars = field.toDouble()
        } catch (e: NumberFormatException) {
            // no-op
        }
    }

    @SerializedName("price")
    var priceString: String = "-1"
    set (value) {
        field = value
        try {
            priceInDollars = field.toDouble()
        } catch (e: NumberFormatException) {
            // no-op
        }
    }

    @SerializedName("imageUrl")
    override var imageUrl: String = ""

    var originalPriceInDollars = -1.0

    var priceInDollars = -1.0

    override fun getOriginalPrice(): Double {
        if (originalPriceInDollars < 0) {
            return 0.0
        } else {
            return originalPriceInDollars
        }
    }

    override fun getPrice(): Double {
        if (priceInDollars < 0) {
            return 0.0
        } else {
            return priceInDollars
        }
    }

}

