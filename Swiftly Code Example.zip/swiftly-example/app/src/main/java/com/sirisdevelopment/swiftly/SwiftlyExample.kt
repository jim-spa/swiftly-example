package com.sirisdevelopment.swiftly

import android.app.Application
import android.content.Context
import com.sirisdevelopment.swiftly.data.SwiftlyData
import com.sirisdevelopment.swiftly.models.SwiftlyDataModel
import timber.log.Timber

class SwiftlyExample : Application() {

    companion object {
        lateinit var context : Context
        lateinit var swiftlyDataModel : SwiftlyDataModel
        lateinit var swiftlyData : SwiftlyData
    }

    override fun onCreate() {
        super.onCreate()
        context = super.getApplicationContext();
        Timber.plant(Timber.DebugTree());
        swiftlyDataModel =
            SwiftlyDataModel(
                context
            )
        swiftlyData = SwiftlyData(context)
    }
}