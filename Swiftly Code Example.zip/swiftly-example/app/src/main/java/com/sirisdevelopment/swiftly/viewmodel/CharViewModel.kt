package com.sirisdevelopment.swiftly.viewmodel

import android.graphics.Bitmap

class CharViewModel {
    lateinit var emblem : Bitmap
    lateinit var light : Bitmap
    lateinit var name : String
    lateinit var lightValue : String

}