package com.sirisdevelopment.swiftly.data

import android.content.Context
import android.net.ConnectivityManager
import com.sirisdevelopment.swiftly.BuildConfig
import com.sirisdevelopment.swiftly.SwiftlyExample
import okhttp3.*
import okhttp3.logging.HttpLoggingInterceptor
import java.io.File


class SwiftlyData(context: Context) {

    var context: Context

    init {
        this.context = context
    }

    fun isOnline(): Boolean {
        val cm =
            SwiftlyExample.context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val netInfo = cm.activeNetworkInfo
        return netInfo != null && netInfo.isConnectedOrConnecting
    }

    fun createClient(context: Context, useCache : Boolean): OkHttpClient? {
        val okHttpClientBuilder = OkHttpClient.Builder()
        if (useCache) {
            val httpCacheDirectory = File(context.getCacheDir(), "cache_file")
            val cache = Cache(httpCacheDirectory, 20 * 1024 * 1024)
            okHttpClientBuilder
                .cache(cache)
                .addInterceptor(
                    Interceptor {
                        val originalRequest: Request = it.request()
                        val cacheHeaderValue =
                            if (isOnline()) "public, max-age=2419200" else "public, only-if-cached, max-stale=2419200"
                        val request: Request = originalRequest.newBuilder().build()
                        val response: Response = it.proceed(request)
                        response.newBuilder()
                            .removeHeader("Pragma")
                            .removeHeader("Cache-Control")
                            .header("Cache-Control", cacheHeaderValue)
                            .build()
                    }
                )
                .addInterceptor(
                    Interceptor {
                        val originalRequest: Request = it.request()
                        val cacheHeaderValue =
                            if (isOnline()) "public, max-age=2419200" else "public, only-if-cached, max-stale=2419200"
                        val request: Request = originalRequest.newBuilder().build()
                        val response: Response = it.proceed(request)
                        response.newBuilder()
                            .removeHeader("Pragma")
                            .removeHeader("Cache-Control")
                            .header("Cache-Control", cacheHeaderValue)
                            .build()

                    }
                )
        }

        okHttpClientBuilder.addInterceptor(SwiftlyDataInterceptor(context,60))

        okHttpClientBuilder.addInterceptor(HttpLoggingInterceptor().apply {
                level = if (BuildConfig.DEBUG) HttpLoggingInterceptor.Level.BODY else HttpLoggingInterceptor.Level.NONE
            })

        var okHttpClient = okHttpClientBuilder.build()
        return okHttpClient
    }
}
