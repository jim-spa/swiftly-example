package com.sirisdevelopment.swiftly.data

import android.content.Context
import com.sirisdevelopment.swiftly.util.SingletonHolder

class SwiftlyRepository private constructor(context: Context) {

    companion object : SingletonHolder<SwiftlyRepository, Context>(::SwiftlyRepository)

    val swiftlyGrocerApi : SwiftlyGrocerAPI

    init {
        swiftlyGrocerApi = SwiftlyServiceGenerator().createService(context, SwiftlyGrocerAPI::class.java)
    }

    //fun getUser() : MutableLiveData<>

}