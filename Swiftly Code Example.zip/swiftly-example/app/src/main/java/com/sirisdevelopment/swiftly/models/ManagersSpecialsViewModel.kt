package com.sirisdevelopment.swiftly.models

import androidx.lifecycle.ViewModel
import com.sirisdevelopment.swiftly.SwiftlyExample
import com.sirisdevelopment.swiftly.SwiftlyExample.Companion.swiftlyDataModel
import com.sirisdevelopment.swiftly.data.SwiftlyData
import io.reactivex.disposables.CompositeDisposable

class ManagersSpecialsViewModel() : ViewModel() {

    lateinit var managersSpecialListDataModel: ManagersSpecialListDataModel

    private val subscriptions = CompositeDisposable()

    init {
        subscriptions.add(swiftlyDataModel.grocerManagersSpecialManagersSpecialDataObservable.subscribe {
            value -> managersSpecialListDataModel = value
        })
    }
}