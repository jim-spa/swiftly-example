package com.sirisdevelopment.swiftly.ui.specials

import android.graphics.drawable.Drawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.databinding.BindingAdapter
import androidx.fragment.app.Fragment
import com.sirisdevelopment.swiftly.R
import com.sirisdevelopment.swiftly.models.ManagersSpecialListDataModel
import com.sirisdevelopment.swiftly.models.SwiftlyDataModel
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.fragment_char_test_display.*
import timber.log.Timber

class CurrentManagersSpecialsDisplayFragment : Fragment() {

    lateinit var swiftlyDataModel : ManagersSpecialListDataModel
    lateinit var managersSpecialsViewModel : ManagersSpecialListDataModel

    override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {

        Timber.d("onCreateView")

        swiftlyDataModel =
            SwiftlyDataModel(
                container!!.context
            )

        managersSpecialsViewModel = swiftlyDataModel.retrieveSwiftlyGrocerManagersSpecialDataPacket()

        return inflater.inflate(R.layout.fragment_char_test_display, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        char_light.setText(singleCharacterData.light.toString())
    }

    @BindingAdapter("customText")
    fun setCustomText(view: TextView, text: String) {
        view.setText(text)
    }

    @BindingAdapter("imageUrl", "error")
    fun loadImage(view: ImageView, url: String, error: Drawable) {
        Picasso.get().load(url).error(error).into(view)
    }
}
