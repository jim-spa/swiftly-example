package com.sirisdevelopment.swiftly.models

interface ManagerSpecialDataModel {
    var displayName: String

    var height: Int

    var width: Int

    fun getOriginalPrice(): Double

    fun getPrice(): Double

    var imageUrl: String
}
