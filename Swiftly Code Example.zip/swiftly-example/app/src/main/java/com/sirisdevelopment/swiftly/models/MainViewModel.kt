package com.sirisdevelopment.swiftly.models

import com.sirisdevelopment.swiftly.SwiftlyExample
import com.sirisdevelopment.swiftly.data.SwiftlyGrocerAPI
import com.sirisdevelopment.swiftly.data.SwiftlyServiceGenerator
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.async
import timber.log.Timber

class MainViewModel {

    val context by lazy {
        SwiftlyExample.context
    }

    fun getSwiftlyGrocerManagersSpecialsAsync() = GlobalScope.async {
        Timber.d("getSwiftlyGrocerManagersSpecials: started...")
        val swiftlyGrocerAPI =
            SwiftlyServiceGenerator().createService(context, SwiftlyGrocerAPI::class.java)
        val call = swiftlyGrocerAPI.retrieveSwiftlyGroverManagerSpecials()

        Timber.d("getSwiftlyGrocerManagersSpecials: retrieveSwiftlyGroverManagerSpecials started..")
        var swiftlyGrocerDataPacket = call.execute().body()
        Timber.d(
            "getSwiftlyGrocerManagersSpecials: swiftlyGrocerDataPacket[%s]",
            swiftlyGrocerDataPacket.toString()
        )
    }
}