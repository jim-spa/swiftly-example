package com.sirisdevelopment.swiftly.models

import com.sirisdevelopment.swiftly.data.objects.SwiftlyManagerSpecialItem

interface ManagersSpecialListDataModel {
    var canvasUnit: Int

    var managerSpecialItemList: List<SwiftlyManagerSpecialItem>
}
